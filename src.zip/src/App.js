import React, { useState } from 'react';
import ColorButtons from './components/ColorButtons';
import './App.css';

function App() {
  const [bgColor, setBgColor] = useState('white');

  const handleColorChange = (color) => {
    setBgColor(color);
  };

  return (
    <div className="App" style={{ backgroundColor: bgColor }}>
      <h1>Change Background Color</h1>
      <ColorButtons onColorChange={handleColorChange} />
    </div>
  );
}

export default App;