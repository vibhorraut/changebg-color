import React from 'react';
import './ColorButtons.css';

const colors = ['red', 'green', 'blue', 'yellow', 'purple', 'orange'];

function ColorButtons({ onColorChange }) {
  return (
    <div className="color-buttons">
      {colors.map((color) => (
        <button
          key={color}
          className="color-button"
          style={{ backgroundColor: color }}
          onClick={() => onColorChange(color)}
        >
          {color.charAt(0).toUpperCase() + color.slice(1)}
        </button>
      ))}
    </div>
  );
}

export default ColorButtons;